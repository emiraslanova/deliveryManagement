package com.div;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
