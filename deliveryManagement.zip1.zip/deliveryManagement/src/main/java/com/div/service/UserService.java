package com.div.service;

import com.div.dto.UserDto;
import com.div.entity.User;
import com.div.mapper.UserMapper;
import com.div.repository.UserRepository;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserService {

    private final UserRepository userRepository;


    private final UserMapper map;

    public UserService(UserRepository userRepository, UserMapper map) {
        this.userRepository = userRepository;
        this.map = map;
    }


    public UserDto creatUser(UserDto userDto) {
        User user = map.toUser(userDto);
        User savedUser = userRepository.save(user);
        UserDto savedUserDto = map.toDto(savedUser);
       return savedUserDto;




        //   userRepository.save(map.toUser(userDto));
    }

    public List<UserDto> getAllUser() {

        List<User> all= userRepository.findAll();

        List<UserDto> userDtoList = all.stream()
                .map(map::toDto)
                .collect(Collectors.toList());

        return userDtoList;
    }

    public UserDto getUserById(Long id) {
        User user = userRepository.findById(id).orElse(null);


        return map.toDto(user);
    }

    public void updateUserById(Long id, UserDto userDto) {

//        User oldUser = userRepository.findById(id).orElse(null);
//        if (oldUser != null) {
//            oldUser.setName(userDto.getName());
//            User save = userRepository.save(oldUser);
//            UserDto dto = map.toDto(save);
//
//        }
        Optional<User> userOptional = userRepository.findById(id);

        if (userOptional.isPresent()){
            User olduser=userOptional.get();
            olduser.setName(userDto.getName());
            olduser.setSurname(userDto.getSurname());
            olduser.setBirthdate(userDto.getBirthdate());
            olduser.setPhoneNumber(userDto.getPhoneNumber());
            olduser.setEnabled(userDto.isEnabled());
            userRepository.save(olduser);
        }

    }

    public void deleteUser(Long id) {

    userRepository.deleteById(id);

    }
}
