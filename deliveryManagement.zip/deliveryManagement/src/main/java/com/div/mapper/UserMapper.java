package com.div.mapper;

import com.div.dto.UserDto;
import com.div.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;




@Mapper(componentModel = "spring")

public interface UserMapper  {
//  @Mapping(target = "isEnabled", source = "isEnabled")
 // @Mapping(target = "id",ignore = true)

  UserDto toDto(User user);


//  @Mapping(target = "isEnabled", source = "isEnabled")
  User toUser(UserDto dto);



}
