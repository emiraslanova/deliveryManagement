package com.div.controller;

import com.div.dto.UserDto;
import com.div.service.UserService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    private  final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    public UserDto  creatUser( @RequestBody UserDto userDto){
      return  userService.creatUser(userDto);

    }

    @GetMapping
    public List<UserDto> getAllUser(){
        return userService.getAllUser();
    }

    @GetMapping("/{id}")

    public UserDto getUserById(@PathVariable Long id){
        return userService.getUserById(id);
    }

   @PutMapping("/{id}")

    public void updateUserById( @PathVariable Long id ,@RequestBody UserDto userDto){
        userService.updateUserById(id,userDto);
   }
  @DeleteMapping("/{id}")
 public void deleteUser(@PathVariable Long id){
        userService.deleteUser(id);
  }
}
