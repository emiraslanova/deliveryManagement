package com.div.config;

import com.div.mapper.OrderMapper;
import com.div.mapper.RoleMapper;
import com.div.mapper.UserMapper;
import org.springframework.context.annotation.Bean;
@org.springframework.context.annotation.Configuration

public class Configuration {



//        @Bean
//        public UserMapper userMapper() {
//            return UserMapper.MAPPER;
//        }
//        @Bean
//   public RoleMapper roleMapper(){
//            return RoleMapper.MAPPER;
//        }
//        @Bean
//
//    public OrderMapper orderMapper(){
//            return OrderMapper.MAPPER;
//        }

    }


